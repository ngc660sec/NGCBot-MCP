from BotCore.Interface import *


async def send_text(text: str, receiver: str):
    """
    给微信好友或群聊发送消息
    :param text:
    :param receiver:
    :return:
    """
    jsonData = await sendPostReq('/text', {'msg': text, 'receiver': receiver})
    message = jsonData.get('status')
    return message


async def push_msg(text: str, roomType):
    """
    给黑名单,白名单,推送群聊发消息
    :param text:
    :param roomType:
    :return:
    """
    jsonData = await sendPostReq('/send-room-text', {'msg': text, 'roomType': roomType})
    message = jsonData.get('status')
    return message


async def get_wxId(wxName: str):
    """
    获取微信名或群聊名对应的wxId
    :param wxName:
    :return:
    """
    jsonData = await sendGetReq('/get-name-wxid', {'wxName': wxName})
    status = jsonData.get('status')
    if status == 0:
        wxId = jsonData.get('data').get('wxId')
        return wxId
    return None
