import BotCore.botCore as bc


def register_tools(mcp):
    @mcp.tool("send_text", description='给微信好友或群聊发消息')
    async def send_message(text: str, receiver: str):
        if not text:
            raise ValueError('请输入要发送的内容!')
        elif not receiver:
            raise ValueError('请输入要接收的对象!')
        elif 'wxid_' not in receiver:
            raise ValueError('请先获取 wxId!')
        message = await bc.send_text(text, receiver)
        return message

    @mcp.tool('get_wxid', description='获取微信好友或群聊的wxId')
    async def get_wxId(wxName: str):
        wxId = await bc.get_wxId(wxName)
        if wxId:
            return wxId
        else:
            raise ValueError('未找到该wxId!')
